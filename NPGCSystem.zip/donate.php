<?php require '/temp/head.php'?>	
<title>โดเนท | NPGCSystem</title>
<header id="header">
<?php require '/temp/navbar.php'?>
<section class="box">
									<h3>โดเนท</h3>

									<h4>สามารถโดเนทได้ทางช่องทางดังนี้เลย</h4>
									<div class="table-wrapper">
										<table class="alt">
											<tbody>
											 <center>
												<tr>
													<td>TrueWallet</td>
													<td>เบอร์: 0955276744</td>
												</tr>
												<tr>
													<td>PayPal</td>
													<td><a href="https://paypal.me/napolgamerth">โอนเลย!</a></td>
												</tr>
												<tr>
													<td>Truemoney</td>
													<td>เร็วๆนี้</td>
												</tr>
											 </center>
											</tbody>
										</table>
									</div>
								</section>
<?php require '/temp/footer.php'?>								
								