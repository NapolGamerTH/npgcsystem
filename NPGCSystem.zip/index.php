<?php require '/temp/head.php'?>
<title>หน้าแรก | NPGCSystem</title>

<body class="landing">

<header id="header" class="alt">
<?php require '/temp/navbar.php' ?>
<!-- Banner -->
<section id="banner">
    <h2>NPGCSystem</h2>
    <p>ระบบตัวรันเซิร์ฟมายคราฟพีอี</p>
    <ul class="actions">
        <li><a href="download.php" class="button special">ดาวน์โหลด</a></li>
        <li><a href="contact.php" class="button">ติดต่อ</a></li>
    </ul>
</section>

<!-- Main -->
<section id="main" class="container">

<section class="box special">
    <header class="major">
        <h2>ตัวรันเซิร์ฟเวอร์ใหม่ล่าสุด
        <br />
        NPGCSystem</h2>
        <p>ไม่มีขีดจำกัดในการใช้งานของตัวรันนี้ และดาวน์โหลดฟรีไม่เสียเงิน ฟังชั่นไม่ซ้ำใคร มีฟีเจอร์เยอะ</p>
    </header>
</section>

<section class="box special features">
    <div class="features-row">
        <section>
            <span class="icon major fa-bolt accent2"></span>
            <h3>ปลั๊กอิน</h3>
            <p>เป็นตัวช่วยของเซิร์ฟ และยังสามารถรัน api เวอร์ชั่นเก่าได้ นี้คือฟังชั่นของตัวรันเซิร์ฟนี้</p>
        </section>
        <section>
            <span class="icon major fa-globe accent2"></span>
            <h3>โลก</h3>
            <p>สามารถรองรับได้หลายโลก หรือสามารถโหลดมาลงได้เลย ไม่ต้องสร้างให้เสียเวลา</p>
        </section>
    </div>
	    <div class="features-row">
        <section>
            <span class="icon major fa-file accent3"></span>
            <h3>จัดการไฟล์</h3>
            <p>จัดการง่ายๆ และแก้ไขง่ายๆ ไม่เสียเวลาในการจัดการไฟล์ต่างๆ</p>
        </section>
        <section>
            <span class="icon major fa-server accent3"></span>
            <h3>เซิร์ฟเวอร์</h3>
            <p>เปิดได้ไม่จำกัด และยังมีการตั้งค่าจำนวนผู้เล่น มากหรือน้อย ตามใจคนใช้งานเลย </p>
        </section>
    </div>
	    <div class="features-row">
        <section>
            <span class="icon major fa-wrench accent4"></span>
            <h3>ไม่มีขีดจำกัดในการควบคุม</h3>
            <p>ควบคุมได้สบายทั้งในเกมและนอกเกม เป็นฟังชั่นของทุกตัวรันในเซิร์ฟมายคราฟ</p>
        </section>
        <section>
            <span class="icon major fa-plus accent4"></span>
            <h3>มากมายหลากหลายฟังชั่น</h3>
            <p>มีหลากหลายฟีเจอร์ และยังเป็นตัวรันเวอร์ชั่นล่าสุดที่รองรับมายคราฟพีอีเวอร์ชั่นปัจจุบัน</p>
        </section>
    </div>
</section>
<?php require '/temp/footer.php' ?>
