<div class="row">
    {% for post in site.posts limit:site.tiles-count %}
    {% if site.tiles-source == 'posts' %}
        <div class="6u 12u(narrower)">
            <section class="box special">
                {% if post.image != blank %}
                    <span class="image featured"><img src="{{ post.image }}" alt="" /></span>
                {% endif %}
                    <h3>{{ post.title }}</h3>
                    <p>{{ post.description }}</p>
                    <ul class="actions">
                            <li><a href="{{ site.baseurl }}{{ post.url }}" class="button alt">Learn More</a></li>
                    </ul>
            </section>
        </div>
    {% endif %}
    {% endfor %}
</div>