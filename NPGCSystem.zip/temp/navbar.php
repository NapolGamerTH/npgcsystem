        <h1>
<a href="index.php">NPGCSystem</a></h1>
        <nav id="nav">
            <ul>
                <li><a href="index.php">หน้าแรก</a></li>
                
                <li><a href="/download.php">ดาวน์โหลด</a></li>
                
                <li><a href="/contact.php">ติดต่อ</a></li>
				
				<li><a href="/donate.php">โดเนท</a></li>
                <li>
                    <a href="#" class="icon fa-angle-down">อื่นๆ</a>
                    <ul>
                        <li><a href="#kuyart">...</a></li>
                        <li><a href="#ihereart">...</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
    </header>