<!-- Footer -->
	<footer id="footer">
		<div class="inner">
			<ul class="icons">
			    <li><a href="https://github.com/NapolGamerTH" class="icon fa-github" target="_blank"><span class="label">Github</span></a></li>
				<li><a href="https://www.youtube.com/c/NapolGamerTH" class="icon fa-youtube-square" target="_blank"><span class="label">YouTube</span></a></li>
				<li><a href="https://www.facebook.com/NapolGamerTH" class="icon fa-facebook-official" target="_blank"><span class="label">Facebook</span></a></li>
			</ul>
			<ul class="copyright">
				<li>&copy; <a href="index.php" target="_blank">NPGCSystem</a></li>
				<li>ธีม จาก: <a href="https://html5up.net" target="_blank">HTML5 UP</a></li>
				<li>CSS จาก: <a href="https://html5up.net" target="_blank">HTML5 UP</a></li>
				<li>ICON จาก: <a href="https://fontawesome.io" target="_blank">FontAwesome</a></li>
			</ul>
		</div>
	</footer>

</div>

<!-- Scripts -->
	<script src="/assets/js/jquery.dropotron.min.js"></script>
	<script src="/assets/js/jquery.scrollgress.min.js"></script>
	<script src="/assets/js/skel.min.js"></script>
	<script src="/assets/js/util.js"></script>
	<!--[if lte IE 8]><script src="/assets/js/ie/respond.min.js"></script><![endif]-->
	<script src="/assets/js/main.js"></script>
