<?php require '/error/include/header.php'?>
  <body class="background error-page-wrapper background-color background-image">
    <center>
  <div class="content-container shadow">
    <div class="head-line secondary-text-color">
      403
    </div>
    <div class="subheader primary-text-color">
      Forbidden
    </div>
    <div class="hr"></div>
    <div class="context secondary-text-color">
      <p>
        ต้องการกลับหน้าแรกให้คลิก "หน้าแรก"
      </p>
    </div>
    <div class="buttons-container">
      <a class="button" href="/index.php" target="_blank"><span class="fa fa-home"></span> หน้าแรก</a>
    </div>
  </div>
</center>
<?php require '/error/include/js/error.js'?> 
  </body>
</html>
